# DefencePath — complete project download

Live website: https://defencepath.vercel.app

This archive contains the current Vercel application source, frontend, server-side Supabase email/password authentication, route data, tests, build scripts and hosting configuration. START-HERE.md is the current setup guide; older documents also describe the original Sites hosting target.

## Requirements and setup

Use Node.js 22.x and npm. This project has no third-party npm dependencies.

For Vercel, import this folder as a project and use Framework: Other, Build command: npm run build:vercel, Output directory: public. The included vercel.json configures routing.

Set these environment variables in your Vercel project:
- SUPABASE_URL: your Supabase project URL
- SUPABASE_PUBLISHABLE_KEY: your project's publishable key

Use .env.example for the variable names. Runtime credentials are not included. Your existing hosted Supabase project and Vercel settings are separate from this ZIP. Do not use a service-role key.

In Supabase Authentication URL Configuration, set the Site URL to your production domain and allow https://YOUR-DOMAIN/?mode=login. For the current deployment these are https://defencepath.vercel.app and https://defencepath.vercel.app/?mode=login.

Deploy to Vercel, then check signup, email confirmation, login and logout. The owner reports the current website is working. This download does not repeat the live account tests.

## Checks

npm run build:vercel
npm test

For a local preview of the welcome page only:
node scripts/build.mjs
npm run dev
Open http://localhost:5173. The simple local preview adapter does not wire the hosted authentication environment or POST bodies. Test complete authentication on Vercel.

## Contents and limits

web/ contains the interface, route records and planning logic. worker/handler.js implements shared authentication and routing. api/site.mjs is the Vercel adapter. scripts/ contains build tools. tests/ contains the automated checks. .openai/hosting.json and the generic build script are retained for the original Sites hosting target.

Student progress stays in the browser, scoped per account; it does not sync across devices. Supabase stores authentication accounts. Sessions last up to one hour and require a fresh login. Password recovery is not implemented. Defence eligibility and exam dates require checking against current official notices.

The ZIP contains source and configuration, not database exports, user accounts, passwords, live credentials, installed dependencies or Git history. Build outputs can be regenerated with the included scripts.
