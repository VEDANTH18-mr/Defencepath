# DefencePath production completion plan

The central flow is: Profile → possible entries with reasons → course-specific roadmap → syllabus/resources → physical and medical requirements → dates/application → progress.

## 1. Authoritative rule and notification database

Replace broad planning bands with versioned intake-specific rule records. Required fields: entry ID, service, commission/engagement type, intake, gender vacancies, exact inclusive birth-date bounds, nationality/marital rules, category relaxations, domicile, accepted qualifications and subject combinations, aggregate and subject cut-offs, certificate requirements, recognition, appearing/final-year deadlines, primary source, verification date, reviewer and review status.

Return `potential`, `missing_information`, `future_education_path` or `does_not_meet_recorded_rule`; never infer absent marks or certificates. Expired or unverified records should not support a confirmed match. Add education-completion estimates so a student sees whether a future qualification could overlap the entry age window. Separate alternative qualifications rather than treating all diplomas as equivalent.

Extend coverage with Navy graduate branches, Army Technical and specialist regular-cadre categories, AFMC/medical, nursing, pharmacy, sports and applicable NCC service routes. Keep Coast Guard separate from the three Armed Forces. CAPF can be an optional separate category; do not label it the Army.

## 2. Content review and administration

Add an authenticated editor role, draft/review/publish workflow, source snapshots, change history, stale-record alerts and correction reports. Require a second review for eligibility, medical and retirement-policy changes. Display a verification date per record. Historical notices should be labelled archived and cannot be used for current applications.

## 3. Verified academy directory

Collect actual academy profiles with consent: name, verified address/coordinates, teaching language, course tags, fees, physical training facilities, instructor credentials, refund terms, evidence of outcomes and verification date. Geocode records and sort distance from a user-chosen town/postcode. Ask before precise location access. Provide filters and a comparison shortlist. Disclose sponsorship on every paid placement; payment must not grant a verification badge or change eligibility recommendations.

## 4. Real stories and journal

Invite selected candidates and serving/retired personnel to contribute. Obtain permission for names, images, recordings and quotations. Confirm course/intake and service claims, label opinions, add captions/transcripts and avoid disclosing operational or private information. Add topics such as school subject choice, SSB preparation, family perspective, women in service, realistic daily life and post-service planning. Link to approved videos instead of copying them.

## 5. Accounts and reminders

Introduce optional sign-in, secure per-user profiles and progress sync. Do not require an account to read guidance. Add user-controlled exam watchlists and opt-in reminders tied to published, reviewed notification records. Track delivery, unsubscribe and data deletion. Never send recruitment deadlines from an unverified scrape.

## 6. Quality before public launch

Test exact inclusive birth-date edges, school/degree variants, marks, branch mappings, certificate conditions, women/men categories, relaxation rules and expired notices. Review language with students from Arts, Commerce, PCM, PCB, ITI and diploma backgrounds. Check mobile layouts, keyboard navigation, contrast and screen readers. Add Hindi/local-language content with a reviewed translation workflow.

## Recommended order

1. Student-test the current eligibility-first interaction.
2. Implement the versioned rule database and editorial controls.
3. Complete verified entry and exam data.
4. Add verified academy records and real contributor interviews.
5. Add optional accounts and notifications.
6. Launch free student access; introduce transparently sponsored academy listings only after trust and coverage are established.
