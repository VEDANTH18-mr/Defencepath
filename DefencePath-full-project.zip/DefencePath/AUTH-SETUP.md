# Supabase connection status

The DefencePath project has been selected and its project URL and active publishable key have been placed in the hosted runtime environment. The key is stored as a secret runtime setting and is not committed to source.

## Verified connection

Supabase Auth settings were reachable with the configured publishable key. Email authentication and signup are enabled, and email confirmation is required. A synthetic invalid-credentials request was rejected as expected. No real account was created and no confirmation email was sent.

## Before public release

- Confirm Email provider and email confirmations are enabled in Supabase.
- Site URL: https://defencepath-student-roadmaps.sprymyna67.chatgpt.site
- Allowed email redirect: https://defencepath-student-roadmaps.sprymyna67.chatgpt.site/?mode=login
- Test signup with an email the tester owns, email confirmation, successful login, invalid credentials and logout. Automated tests use simulated provider responses; they do not prove real email delivery.
- Confirm public access for the signup/login page before removing the owner-private hosting gate. Protected application routes continue to require the provider-verified session.
- Configure SMTP and provider rate limits for a wider student launch; add password recovery.

Only the project's publishable key is needed. Never configure a service-role key for this flow. Preparation progress is browser-local and partitioned by account. Sessions expire after at most one hour and require a fresh login.
