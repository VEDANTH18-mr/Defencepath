import { test } from 'node:test';
import assert from 'node:assert/strict';
import application from '../api/site.mjs';
const call = (path, init = {}) => application.fetch(new Request('https://defencepath.example' + path, init));
const originalFetch = globalThis.fetch;

test('Vercel catch-all rewrite serves signup and preserves login query', async () => {
  const signup = await call('/api/site?__path=');
  assert.equal(signup.status, 200);
  assert.match(await signup.text(), /Confirm password/);
  const login = await call('/api/site?__path=&mode=login');
  assert.match(await login.text(), /Enter your email and password/);
});
test('protected rewrites and direct URLs both require a session', async () => {
  assert.equal((await call('/api/site?__path=app')).status, 302);
  assert.equal((await call('/app')).status, 302);
  assert.equal((await call('/api/site?__path=data.js')).status, 401);
});
test('public CSS and form script are served without exposing protected files', async () => {
  const css = await call('/api/site?__path=style.css');
  assert.match(css.headers.get('content-type'), /text\/css/);
  assert.equal((await call('/api/site?__path=account.js')).status, 200);
  assert.equal((await call('/api/site?__path=.env')).status, 404);
});
test('duplicate rewrite parameters are rejected', async () => {
  assert.equal((await call('/api/site?__path=app&__path=style.css')).status, 400);
});
test('Vercel POST rewrite preserves body, origin and secure login cookie', async () => {
  process.env.SUPABASE_URL = 'https://provider.example';
  process.env.SUPABASE_PUBLISHABLE_KEY = 'synthetic-key';
  let providerCalled = false;
  globalThis.fetch = async (url, options) => {
    providerCalled = true;
    assert.match(url, /token\?grant_type=password/);
    assert.equal(JSON.parse(options.body).email, 'student@example.test');
    return Response.json({ access_token: 'synthetic-token', expires_in: 3600, user: { id: 'test' } });
  };
  try {
    const response = await call('/api/site?__path=api%2Fauth%2Flogin', {
      method: 'POST',
      headers: { Origin: 'https://defencepath.example', 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: 'student@example.test', password: 'synthetic-password' }),
    });
    assert.equal(providerCalled, true);
    assert.equal(response.status, 200);
    assert.match(response.headers.get('Set-Cookie'), /HttpOnly; Secure; SameSite=Lax/);
    assert.deepEqual(await response.json(), { authenticated: true });
  } finally {
    globalThis.fetch = originalFetch;
    delete process.env.SUPABASE_URL;
    delete process.env.SUPABASE_PUBLISHABLE_KEY;
  }
});
test('server-side user verification still protects the rewritten dashboard', async () => {
  process.env.SUPABASE_URL = 'https://provider.example';
  process.env.SUPABASE_PUBLISHABLE_KEY = 'synthetic-key';
  globalThis.fetch = async () => Response.json({ id: 'vercel-student', email: 'student@example.test' });
  try {
    const response = await call('/api/site?__path=app', { headers: { Cookie: '__Host-dp-access=synthetic-token' } });
    assert.equal(response.status, 200);
    assert.match(await response.text(), /data-account="vercel-student"/);
    assert.match(response.headers.get('Cache-Control'), /no-store/);
  } finally {
    globalThis.fetch = originalFetch;
    delete process.env.SUPABASE_URL;
    delete process.env.SUPABASE_PUBLISHABLE_KEY;
  }
});
