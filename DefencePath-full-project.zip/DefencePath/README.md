# DefencePath — eligibility-first student guidance

A working responsive release, rebuilt after reviewing the supplied Milestone 1 React shell. This implementation is a separate dependency-free HTML/CSS/JavaScript application; it does not silently overwrite the original ZIP or pretend its placeholder pages were complete.

## Run locally

From this directory: `node scripts/build.mjs` then `node scripts/dev.mjs`

Open `http://localhost:5173`. The local preview shows the welcome and account screens. Protected pages require the trusted identity headers supplied by Sites in production. No local password or fake logged-in flag is used. The site now deploys as an ESM Worker.

Run checks: `node --test tests/*.test.*` after building.

## Implemented

- Three-step profile questionnaire: date of birth, recruitment category, nationality, marital status, education, current/planned stream, optional aggregate and English marks, service interest, career type and city.
- Eighteen route briefs covering school, any-stream, ITI/diploma and graduate planning, including NDA Army, NDA Navy/Air, Army GD/Tradesman/Office Assistant/WMP, Navy MR/SSR, Agniveervayu subject groups, CDS Army, SSC Technical, TGC, TES, NCC, JAG, AFCAT Ground Duty and Coast Guard categories.
- Transparent broad planning logic: potential route, plan ahead, requirements differ and individual review. Requirements and reasons are shown. No candidate is certified eligible.
- Route-specific study focus, exam pattern, selection stages, step-by-step roadmap, reference resources and official links.
- Four 2027 NDA/CDS annual-calendar records, personal-route calendar filtering, application/notification/exam dates and downloadable .ics calendar files.
- Optional reference books, free NCERT texts, previous paper links and a four-week study framework.
- Fitness and medical requirement categories with entry-specific sources; no generic medical fit/unfit decision.
- City + training-focus Google Maps academy search, provider comparison checklist and sponsored-listing policy.
- Service journal with official women-in-service features, external talk discovery, service/retirement distinctions, veteran resources and a selected rank-equivalence table.
- Saved route shortlist, checklist progress, printable plan, downloadable text plan and local data deletion.
- Keyboard focus states, modal escape support, form labels, responsive navigation and source/privacy page.

## Important boundaries

This is a first release with browser-local state, not a finished full-stack recruitment database. Age ranges are broad planning aids, not exact intake eligibility windows. Marks are retained as checklist inputs but do not automatically validate minimum aggregate or subject cut-offs. The checker does not collect every subject, certificate, degree recognition, reservation, domicile or waiver condition. NCC certification is explicitly sent for individual review. ITI, diploma and engineering recognition must be checked in the actual notice. A possible future route may not fit the student's eventual completion date.

Dates are annual-calendar planning dates and can change. The 2027 UPSC calendar PDF was checked on 29 October 2026. Reference notices are not automatically refreshed. No background email/push notification service is active.

Academy search opens a third-party Maps search; it does not calculate verified distances or rank accredited academies. No verified academy listings, paid placements or original candidate interviews are fabricated. The journal links public official features and external searches. Actual interviews require contributors, consent and verification.

Medical/health, welfare and pension eligibility are determined by competent authorities under current rules, not by this site. Officer commissions, regular enlisted service and Agniveer engagements have different terms.

## Files

- `web/index.html`: application shell.
- `web/style.css`: visual system and responsive layouts.
- `web/data.js`: route, event, book and source records.
- `web/engine.js`: pure planning functions, isolated for tests.
- `web/app.js`: interface, local storage, calendar export and interactions.
- `tests/pathways.test.cjs`: eight core qualification/stream/category checks.
- `PRODUCT-ROADMAP.md`: next steps for the complete production service.

## Privacy

Only localStorage holds the profile, shortlist and checklist. Do not enter medical records or government IDs. External links use the destination service's policies. Google Fonts is optional; system fonts are the fallback. No analytics or payment code is included.

## Account-first entry flow

`/` starts on Create account. `/?mode=login` shows Log in. The email/password forms use Supabase Auth through server-side API endpoints. Provider-issued access tokens use HttpOnly, Secure, SameSite cookies; protected content is served only after the provider verifies the current user. Sessions last up to one hour and then require login again. Signup may require email confirmation, depending on provider settings.

The runtime uses `SUPABASE_URL` and `SUPABASE_PUBLISHABLE_KEY` stored in Sites environment configuration. The publishable key is not a service-role key. No secrets are stored in this repository. Cross-origin POST requests are rejected. Application scripts and route data return 401 without a valid session; `/app` redirects to login.

Preparation data remains in the browser, partitioned by authenticated account ID. Earlier unscoped browser data is not imported automatically. Password recovery and cross-device progress sync are not included yet.

The site's existing owner-private audience is preserved until the owner explicitly approves public access to the signup/login landing page. That hosting boundary is independent of the application authentication.

Source assets live in `web/`; `worker/handler.js` handles authentication and routing. `scripts/build.mjs` embeds the assets in `dist/server/index.js`. The manifest has no static directory, so protected content cannot bypass the Worker.
