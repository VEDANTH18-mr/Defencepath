import {readFile,mkdir,rm,writeFile,copyFile} from 'node:fs/promises';
const names=['welcome.html','index.html','style.css','app.js','data.js','engine.js','account.js'];
const assets={};for(const name of names)assets[name]=await readFile(new URL('../web/'+name,import.meta.url),'utf8');
const handler=await readFile(new URL('../worker/handler.js',import.meta.url),'utf8');
const output=new URL('../dist/',import.meta.url);
await rm(output,{recursive:true,force:true});await mkdir(new URL('server/',output),{recursive:true});await mkdir(new URL('.openai/',output),{recursive:true});
await writeFile(new URL('server/index.js',output),'const ASSETS = '+JSON.stringify(assets)+';\n'+handler);
await copyFile(new URL('../.openai/hosting.json',import.meta.url),new URL('.openai/hosting.json',output));
console.log('Built authenticated DefencePath Worker');
