const privatePaths = new Set(['/app','/app/','/app.js','/data.js','/engine.js']);
function respond(body,type='text/html; charset=utf-8',status=200,extra={}){return new Response(body,{status,headers:{'Content-Type':type,'Cache-Control':'private, no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin',...extra}})}
const json=(body,status=200,headers={})=>respond(JSON.stringify(body),'application/json',status,headers);
function configured(env){try{return new URL(env.SUPABASE_URL).protocol==='https:'&&Boolean(env.SUPABASE_PUBLISHABLE_KEY)}catch{return false}}
async function provider(env,path,options={}){return fetch(env.SUPABASE_URL.replace(/\/$/,'')+'/auth/v1/'+path,{...options,headers:{apikey:env.SUPABASE_PUBLISHABLE_KEY,'Content-Type':'application/json',...options.headers},signal:AbortSignal.timeout(10000)})}
function accessToken(request){const match=(request.headers.get('cookie')||'').split(';').map(s=>s.trim()).find(s=>s.startsWith('__Host-dp-access='));return match?match.slice('__Host-dp-access='.length):null}
async function getUser(request,env){const token=accessToken(request);if(!configured(env)||!token||token.length>8000)return null;try{const r=await provider(env,'user',{headers:{Authorization:'Bearer '+token}});if(!r.ok)return null;const user=await r.json();return user.id&&user.email?user:null}catch{return null}}
function sessionCookie(token,expires){return '__Host-dp-access='+token+'; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age='+Math.max(1,Math.min(Number(expires)||3600,3600))}
function sameOrigin(request){return request.headers.get('origin')===new URL(request.url).origin}
export default {async fetch(request,env={}){
 const url=new URL(request.url),path=url.pathname;
 if(path.startsWith('/api/auth/')){
  if(request.method!=='POST')return json({message:'Use POST.'},405);
  if(!sameOrigin(request))return json({message:'Request not allowed.'},403);
  if(!configured(env))return json({message:'Account services are not connected yet. Please try again after setup.'},503);
  const action=path.slice('/api/auth/'.length);
  if(action==='logout'){
   const token=accessToken(request);if(token){try{await provider(env,'logout',{method:'POST',headers:{Authorization:'Bearer '+token}})}catch{}}
   return new Response(null,{status:303,headers:{Location:'/?mode=login','Cache-Control':'no-store','Set-Cookie':'__Host-dp-access=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0'}});
  }
  if(!['signup','login'].includes(action))return json({message:'Not found.'},404);
  if(!request.headers.get('content-type')?.toLowerCase().includes('application/json'))return json({message:'Use a JSON form request.'},415);
  let text='';try{const reader=request.body?.getReader();if(!reader)return json({message:'Invalid form.'},400);const decoder=new TextDecoder();let bytes=0;while(true){const chunk=await reader.read();if(chunk.done)break;bytes+=chunk.value.byteLength;if(bytes>8192){await reader.cancel();return json({message:'Request too large.'},413)}text+=decoder.decode(chunk.value,{stream:true})}text+=decoder.decode()}catch{return json({message:'Invalid form.'},400)}
  let body;try{body=JSON.parse(text)}catch{return json({message:'Invalid form.'},400)}
  const email=String(body.email||'').trim().toLowerCase(),password=body.password;
  if(!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)||email.length>254||typeof password!=='string'||password.length>1024||password.length<(action==='signup'?12:1))return json({message:action==='signup'?'Enter a valid email and a password of at least 12 characters.':'Enter your email and password.'},400);
  if(action==='signup'&&password!==body.confirm)return json({message:'Your passwords do not match.'},400);
  try{
   const payload=action==='signup'?{email,password,data:{full_name:String(body.name||'').trim().slice(0,100)}}:{email,password};
   const endpoint=action==='signup'?'signup?redirect_to='+encodeURIComponent(url.origin+'/?mode=login'):'token?grant_type=password';
   const r=await provider(env,endpoint,{method:'POST',body:JSON.stringify(payload)});const result=await r.json();
   if(!r.ok)return json({message:r.status===429?'Too many attempts. Please wait and try again.':action==='login'?'Unable to log in. Check your details and confirm your email first.':'Unable to create the account. Check your details or try logging in.'},r.status===429?429:400);
   if(result.access_token&&result.user)return json({authenticated:true},200,{'Set-Cookie':sessionCookie(result.access_token,result.expires_in)});
   return json({authenticated:false,message:'Check your email to confirm your account, then return here to log in.'});
  }catch{return json({message:'Account service is temporarily unavailable. Please try again.'},503)}
 }
 if(!['GET','HEAD'].includes(request.method))return respond('Method not allowed','text/plain',405);
 let signedInUser=null;
 if(path==='/api/session'||privatePaths.has(path)){
  const user=await getUser(request,env);signedInUser=user;
  if(path==='/api/session')return json({authenticated:Boolean(user)},user?200:401);
  if(!user){if(path==='/app'||path==='/app/')return new Response(null,{status:302,headers:{Location:'/?mode=login','Cache-Control':'no-store'}});return respond('Please log in.','text/plain',401)}
 }
 if(path==='/'||path==='/index.html'||path==='/login'||path==='/signup'){
  const signup=path==='/signup'||(path!=='/login'&&url.searchParams.get('mode')!=='login');
  const copy=signup?{title:'Create account',eyebrow:'YOUR JOURNEY BEGINS HERE',heading:'Your future starts here.',description:'Create an account with your email to open your defence pathways.',cta:'Create account',switchText:'Already have an account?',switchMode:'login',switchLink:'Log in'}:{title:'Log in',eyebrow:'WELCOME BACK TO DEFENCEPATH',heading:'Ready for your next step?',description:'Enter your email and password to open your preparation space.',cta:'Log in',switchText:'New to DefencePath?',switchMode:'signup',switchLink:'Create account'};
  const fields={...copy,mode:signup?'signup':'login',passwordAutocomplete:signup?'new-password':'current-password',passwordMinimum:signup?'12':'1',passwordPlaceholder:signup?'At least 12 characters':'Enter your password',nameField:signup?'<label for="account-name">Full name</label><input id="account-name" name="name" autocomplete="name" required maxlength="100" placeholder="Your name">':'',confirmField:signup?'<label for="confirm-password">Confirm password</label><input id="confirm-password" name="confirm" type="password" autocomplete="new-password" required maxlength="1024" placeholder="Re-enter your password">':'',signupClass:signup?'active':'',loginClass:signup?'':'active',signupCurrent:signup?'aria-current="page"':'',loginCurrent:signup?'':'aria-current="page"'};
  return respond(ASSETS['welcome.html'].replace(/\{\{(\w+)\}\}/g,(_,key)=>fields[key]??''));
 }
 if(path==='/app'||path==='/app/')return respond(ASSETS['index.html'].replace('{{ACCOUNT_SCOPE}}',encodeURIComponent(signedInUser.id)));
 const name=path.slice(1);if(['app.js','data.js','engine.js','style.css','account.js'].includes(name))return respond(ASSETS[name],name.endsWith('.css')?'text/css; charset=utf-8':'text/javascript; charset=utf-8');
 return respond('<h1>Page not found</h1><a href="/">Return to DefencePath</a>','text/html',404);
}};
