# DefencePath on Vercel

## Prepared configuration

This branch adapts the existing application to a Vercel Node.js function. No Cloudflare or Sites credentials are needed on Vercel. The original Sites deployment is unchanged.

- Runtime: Node.js 22.x.
- Framework preset: Other (no framework).
- Build command: `npm run build:vercel`.
- Static output directory: `public` (only a non-sensitive robots.txt).
- Entrypoint: `api/site.mjs`.
- `vercel.json` rewrites requests into the same server-side authentication and routing logic. Protected HTML and JavaScript are never copied to the public directory.
- Supabase access tokens stay in Secure, HttpOnly, SameSite cookies. Anonymous visitors cannot open the pathway dashboard or its protected data assets.

## Before deploying

Install/connect Vercel to the current chat, choose the appropriate Vercel scope/project, and use this prepared source. Environment variables must be set on Vercel, because the existing Sites environment does not transfer automatically:

- `SUPABASE_URL`: the confirmed DefencePath Supabase API URL.
- `SUPABASE_PUBLISHABLE_KEY`: the project's active publishable key, not a service-role key.

No actual keys are included in source or `.env.example`.

After Vercel supplies the production URL, add it as the Site URL in Supabase Authentication URL Configuration and allow the exact `https://YOUR-VERCEL-HOST/?mode=login` redirect. Avoid wildcard production URLs. Review email confirmation delivery; the default Supabase mail service may need SMTP configuration for students outside the project organization.

## Verification

Run `npm run test:vercel` for the adapter and route-protection checks. Before launch, verify the actual Vercel deployment's signup page, login page, denial of anonymous `/app` and `/data.js`, invalid credentials, email confirmation, successful login and logout. Production deployment is READY at https://defencepath.vercel.app (deployment dpl_ALBE8wCP28vDseCaekci4Aqs1QMf). The signup and login pages have been checked in the browser. Add the Vercel origin and exact email redirect to Supabase Auth URL Configuration before relying on confirmation emails.

## Verified production configuration

- Project: prj_T80XlDMGm9fRIjRj5MB70hIPKv0W
- Scope: team_VXQ929ZyKbOj0QbBAX2FWQQH
- URL: https://defencepath.vercel.app
- Application deployment: dpl_ALBE8wCP28vDseCaekci4Aqs1QMf
- Supabase URL and encrypted publishable-key environment variables are configured for production and preview.
- The existing Sites deployment is unchanged. No custom domain was purchased.
- Six adapter tests passed. Real signup/confirmation email delivery still needs testing with an account owned by the tester.
