import application from '../.generated/defencepath.mjs';

export default {
  async fetch(request) {
    const url = new URL(request.url);
    const paths = url.searchParams.getAll('__path');
    if (paths.length > 1) return new Response('Invalid route', { status: 400 });
    if (url.pathname === '/api/site' || url.pathname === '/api/site.mjs') {
      const path = paths[0] || '';
      url.pathname = '/' + path.replace(/^\/+/, '');
    }
    url.searchParams.delete('__path');
    const routed = new Request(url, request);
    return application.fetch(routed, {
      SUPABASE_URL: process.env.SUPABASE_URL,
      SUPABASE_PUBLISHABLE_KEY: process.env.SUPABASE_PUBLISHABLE_KEY,
    });
  },
};
